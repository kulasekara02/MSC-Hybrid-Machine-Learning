# Hybrid Student Success — Inference Guide

This bundle contains:
- Keras SavedModel for the temporal LSTM (folder: keras_savedmodel/)
- Joblib pickles for RF and meta-blender (in preprocessors.pkl)
- Preprocessing objects (static_pipe, temporal_scaler, optional tokenizer_json)
- features.json — static feature order
- metadata.json — label and threshold

## Quick start (Python)
```python
import json, joblib
from pathlib import Path
import numpy as np
import pandas as pd
import tensorflow as tf

root = Path('UNZIPPED_FOLDER')
meta = json.loads((root/'metadata.json').read_text())
features = json.loads((root/'features.json').read_text())
pp = joblib.load(root/'preprocessors.pkl')

lstm = tf.keras.models.load_model(root/'keras_savedmodel')
rf = pp['rf_model']
blender = pp['meta_blender']
static_pipe = pp.get('static_pipe')
temporal_scaler = pp.get('temporal_scaler')
tokenizer_json = pp.get('tokenizer_json')
seq_len = int(pp.get('seq_len', 32))
temporal_features = pp.get('temporal_features')

# X_static: DataFrame with columns exactly equal to 'features'
# X_temp: numpy array of shape (N, seq_len, T_feats)

# Example placeholders:
# X_static = pd.DataFrame([...], columns=features)
# X_temp   = np.zeros((len(X_static), seq_len, len(temporal_features) if temporal_features else 1))

if static_pipe is not None:
    Xs = static_pipe.transform(X_static)
else:
    Xs = X_static[features].values

Xt = X_temp
if temporal_scaler is not None and isinstance(Xt, np.ndarray):
    N, L, F = Xt.shape
    Xt2 = Xt.reshape(N*L, F)
    Xt2 = temporal_scaler.transform(Xt2)
    Xt = Xt2.reshape(N, L, F)

p_lstm = lstm.predict(Xt, verbose=0).reshape(-1, 1)
p_rf   = rf.predict_proba(Xs)[:, 1].reshape(-1, 1)
Z = np.hstack([p_lstm, p_rf])
p_final = blender.predict_proba(Z)[:, 1]
yhat = (p_final >= float(meta.get('threshold', 0.5))).astype(int)
```