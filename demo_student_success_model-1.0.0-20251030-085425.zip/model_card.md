# demo_student_success_model (v1.0.0)

Exported: 20251030-085425

## Contents
- model.pkl - main trained model (joblib)
- preprocessors.pkl - scalers/encoders/pipelines (joblib)
- features.json - training/inference feature order
- metadata.json - label/threshold and export info
- requirements.txt - pip packages for reproduction

## Inference snippet (Python)
```python
import joblib, json
from pathlib import Path

root = Path('UNZIPPED_FOLDER')
model = joblib.load(root/'model.pkl')
pp = joblib.load(root/'preprocessors.pkl')
features = json.loads((root/'features.json').read_text())

# X should be a pandas DataFrame with columns = features
# X = ...

X_t = X.copy()
# apply pp steps if not inside model
y_prob = model.predict_proba(X_t)[:, 1]  # if classifier
```