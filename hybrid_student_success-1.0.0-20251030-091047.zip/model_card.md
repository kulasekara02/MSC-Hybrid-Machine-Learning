# hybrid_student_success (v1.0.0)

Exported: 20251030-091047

## Contents
- model.pkl - main trained model (joblib)
- preprocessors.pkl - scalers/encoders/pipelines and non-Keras models (joblib)
- features.json - training/inference feature order
- metadata.json - label/threshold and export info
- requirements.txt - pip packages for reproduction

## Inference snippet (Python)
```python
import joblib, json
from pathlib import Path

root = Path('UNZIPPED_FOLDER')
model = joblib.load(root/'model.pkl')
pp = joblib.load(root/'preprocessors.pkl')
features = json.loads((root/'features.json').read_text())

# If you need the Keras model:
# import tensorflow as tf
# lstm = tf.keras.models.load_model(root/'keras_savedmodel')
# or: lstm = tf.keras.models.load_model(root/'lstm_model.h5')
```